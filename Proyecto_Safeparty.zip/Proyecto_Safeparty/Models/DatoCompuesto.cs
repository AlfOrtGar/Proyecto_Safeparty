﻿namespace Proyecto_Safeparty.Models
{
    public class DatoCompuesto
    {
        public Local establecimiento {  get; set; }
        public List<Critica> comentario { get; set; }
    }
}
